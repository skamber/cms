________________________________________________________________ 

Crystal Decisions Technical Support - Access2000drivers.zip


Phone: (604) 669-8379

Answers by Email: 
http://support.crystaldecisions.com/support/answers.asp
  
________________________________________________________________ 


PRODUCT VERSION

These updated drivers are for use with version 7 of Crystal Reports (CR) (Prior to CR 7 MR 1) only.

________________________________________________________________ 

DESCRIPTION

This zip file includes the 32-bit native drivers for 
connection to Microsoft Access 2000. 

________________________________________________________________ 


FILES

File		Version Number	Target Directory
P2bdao.dll	7.0.100.2	C:\ win* \system32 directory
p2irdao.dll	7.0.100.2	C:\ win* \system32 directory
p2ctdao.dll	7.0.100.2	C:\ win* \system32 directory

________________________________________________________________ 

INSTALLATION

Note:  Prior to installing the updated drivers, close all applications that are currently using the drivers.  For example, close Microsoft Access and Crystal Reports (CR).

1. Rename the current files (P2bdao.dll, P2irdao.dll, P2ctdao.dll) that exist on your computer.

2. Extract the updated drivers to the C:\ win* \system32 directory

________________________________________________________________ 

ADDITIONAL INFO / LIMITATIONS

These drivers will also work with CR 5, 6 however, support for the updated DLLs is only available with the use of CR 7.  The updated Access 2000 drivers are installed with CR 7 MR 1 and later.

________________________________________________________________ 

Last updated on February 6, 2002
________________________________________________________________ 
